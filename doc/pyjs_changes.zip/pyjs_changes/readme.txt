Pyjs 1.8.1-dev - Changes required for IE9+ compatibility
(Reference: http://blogs-pyjeon.rhcloud.com/?p=312)

Changes allow applications using the Pyjsdl module to run properly in IE9+ browsers. Install Pyjs from its git repository (https://github.com/pyjs/pyjs/). Edit home.nocache.html and browser.py to properly detect IE browsers, see comments in edited files included. Add <!DOCTYPE html> to top of main program html in Pyjs output for standard HTML5 mode. Have not done extensive tests to confirm that changes are completely compatible with Pyjs functionality, therefore verify with the usual application testing.

Pyjs git build:
    Files to change:
        <pyjsroot>/pyjs/boilerplate/home.nocache.html
        <pyjsroot>/pyjs/browser.py
    Following pyjs installation using pip, edit these files or replace with the edited files included.

